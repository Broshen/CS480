The writeup for this assignment can be found in A1_writeup.pdf.
Please extract all files to the same directory, to ensure everything works properly.
To run the programs, run `python A1.py`. Ensure that you have Python 2.7, numpy, matplotlib, and sklearn installed.
Source code can be found in Exercise1.py and Exercise2.py